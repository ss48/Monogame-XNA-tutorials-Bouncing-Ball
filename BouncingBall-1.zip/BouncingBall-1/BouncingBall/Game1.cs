﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace BouncingBall
{
   /// <summary>
   /// This is the main type for your game.
   /// </summary>
   public class Game1 : Game
   {
      GraphicsDeviceManager graphics;
      SpriteBatch spriteBatch;
      Texture2D BallTexture;
      Rectangle BallRectangle;
      Texture2D TileTexture;
      Rectangle TileRectangle;
      Vector2 velocity;
      Random myRandom = new Random();

      int screenWidth;
      int screenHeight;

      public Game1()
      {
         graphics = new GraphicsDeviceManager(this);
         Content.RootDirectory = "Content";
      }

      /// <summary>
      /// Allows the game to perform any initialization it needs to before starting to run.
      /// This is where it can query for any required services and load any non-graphic
      /// related content.  Calling base.Initialize will enumerate through any components
      /// and initialize them as well.
      /// </summary>
      protected override void Initialize()
      {
         // TODO: Add your initialization logic here

         base.Initialize();
      }

      /// <summary>
      /// LoadContent will be called once per game and is the place to load
      /// all of your content.
      /// </summary>
      protected override void LoadContent()
      {
         // Create a new SpriteBatch, which can be used to draw textures.
         spriteBatch = new SpriteBatch(GraphicsDevice);
         BallTexture = Content.Load<Texture2D>("ball");
         BallRectangle = new Rectangle(100, 100, BallTexture.Width, BallTexture.Height);
         
         TileTexture = Content.Load<Texture2D>("tile");
         TileRectangle = new Rectangle(200, 400, TileTexture.Width, TileTexture.Height);
  

         screenWidth=GraphicsDevice.Viewport.Width;
         screenHeight = GraphicsDevice.Viewport.Height;
         // TODO: use this.Content to load your game content here
         
         BallRectangle.X += BallRectangle.X + (int)velocity.X;

      }
      void RandomLoad()
      {
         int random = myRandom.Next(0, 4);
         if (random == 0) 
         {
            velocity.X = 5f;
            velocity.Y = 5f;
         }
         if (random == 1)
         {
            velocity.X = -5f;
            velocity.Y = 5f;
         }
         if (random == 2)
         {
            velocity.X = 5f;
            velocity.Y = -5f;
         }
         if (random == 3)
         {
            velocity.X = -5f;
            velocity.Y = -5f;
         }
      }

      /// <summary>
      /// UnloadContent will be called once per game and is the place to unload
      /// game-specific content.
      /// </summary>
      protected override void UnloadContent()
      {
         // TODO: Unload any non ContentManager content here
      }

      /// <summary>
      /// Allows the game to run logic such as updating the world,
      /// checking for collisions, gathering input, and playing audio.
      /// </summary>
      /// <param name="gameTime">Provides a snapshot of timing values.</param>
      protected override void Update(GameTime gameTime)
      {
         if (Keyboard.GetState().IsKeyDown(Keys.Escape))
            this.Exit();
         if (BallRectangle.Intersects(TileRectangle))
         {
            velocity.Y = -velocity.Y;
         }
        //TILE
         if (Keyboard.GetState().IsKeyDown(Keys.Right)) TileRectangle.X += 3;
         if (Keyboard.GetState().IsKeyDown(Keys.Left)) TileRectangle.X -= 3;
         if (TileRectangle.X <= 0) { TileRectangle.X = 0; }
         if (TileRectangle.X + TileTexture.Width > screenWidth) { TileRectangle.X = screenWidth- TileTexture.Width; }


         BallRectangle.X = BallRectangle.X+(int)velocity.X;
         BallRectangle.Y = BallRectangle.Y + (int)velocity.Y;

        
        // if (Keyboard.GetState().IsKeyDown(Keys.Down)) BallRectangle.Y += 3;
         if (BallRectangle.X <= 0) velocity.X = -velocity.X;
         if (Keyboard.GetState().IsKeyDown(Keys.Space)) {
         
            RandomLoad();
           
         }
           if (BallRectangle.Y <= 0) velocity.Y=-velocity.Y;
           if (BallRectangle.X + BallTexture.Width >= screenWidth)  {velocity.X = -velocity.X;}
           if (BallRectangle.Y + BallTexture.Height >= screenHeight) {velocity.Y = -velocity.Y;}
         
      
         // TODO: Add your update logic here

         base.Update(gameTime);
      }

      /// <summary>
      /// This is called when the game should draw itself.
      /// </summary>
      /// <param name="gameTime">Provides a snapshot of timing values.</param>
      protected override void Draw(GameTime gameTime)
      {
         GraphicsDevice.Clear(Color.CornflowerBlue);

         spriteBatch.Begin();
         spriteBatch.Draw(BallTexture, BallRectangle, Color.White);
         spriteBatch.Draw(TileTexture, TileRectangle, Color.White);
         spriteBatch.End();




         // TODO: Add your drawing code here

         base.Draw(gameTime);
      }
   }
}
